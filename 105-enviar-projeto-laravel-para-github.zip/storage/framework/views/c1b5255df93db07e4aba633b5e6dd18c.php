<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Celke</title>

    </head>
    <body>

        <h1>Bem-vindo ao Laravel 11</h1>

        

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\celke\resources\views/welcome.blade.php ENDPATH**/ ?>